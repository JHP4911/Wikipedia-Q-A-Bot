# WikipediaQuestionBot
Use GPT-3 to scrape and ask questions about a Wikipedia article

## Usage
```pip install -r requirements.txt```

Replace \<YOUR API KEY> with your GPT-3 API key
  
```python3 main.py```

Data from previous accessed Wikipedia pages will be backed up to OpenAI to save API credits
